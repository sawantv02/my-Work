

$(function(){
		//alert("m in");
		
		$(".clicksearch").on("click",function(){
				//alert("YA~YA~YA~YA");
				var detailswindow=window.open('pro_ajax_details.html',"bookDetails","width=400,height=500");
				$("#exampleEmailInput").val("");
				detailsWindow.focus();				
		});
		
		$(document).ready(function(){ 
		
				$("select").change(function(){
					/*alert("hi");*/
					var end=$(this).val();
					//alert(end);
					   $("#myModal").modal();
					   $("select")[0].selectedIndex =0;
				/*var value = $('.last').val();*/
				
		});
		

			   $('#formsub').on("click",function(e) {
				   
					/*alert("in formsub");*/
					var sEmail = $("#usrname").val();
					
								
					if (validateEmail(sEmail)) {
			
						alert('Email is valid');
			
					}

					else {
						$("#uemail").val("");
						alert('Invalid Email Address');
						
						e.preventDefault();
	
					}
			
				});
		
		})
		
		function validateEmail(sEmail) {
		/*alert("in val");
		alert(sEmail);*/
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
		/*alert("in true");*/
        return true;
    }
    else {
        return false;
    }
}
		
	})
	
	
	
	