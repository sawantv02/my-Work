var xmlHttp

function showHint(str)
{
/*alert("in");*/
if (str.length==0)
  { 
  document.getElementById("bookList").innerHTML="";
  return;
  }
xmlHttp=GetXmlHttpObject();
if (xmlHttp==null)
  {
  alert ("Your browser does not support AJAX!");
  return;
  } 
//alert("in url"); 
var url="gethint.jsp";
url=url+"?q="+str;
url=url+"&sid="+Math.random();
xmlHttp.onreadystatechange=stateChanged;
xmlHttp.open("GET",url,true);
xmlHttp.send(null);
} 

function stateChanged() 
{ 
if (xmlHttp.readyState==4)
{ 
//alert("hi");
var str;
var inp=document.getElementById("exampleEmailInput");
inp.setAttribute("List","bookList");
//alert(xmlHttp.responseText);
//alert(inp);
var dataList=document.getElementById("bookList");
/*str += '<option value="'+xmlHttp.responseText+'" />';*/
dataList.innerHTML=xmlHttp.responseText;
/*alert("text");*/

}
}

function GetXmlHttpObject()
{
var xmlHttp=null;
try
  {
  // Firefox, Opera 8.0+, Safari
  xmlHttp=new XMLHttpRequest();
  }
catch (e)
  {
  // Internet Explorer
  try
    {
    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
return xmlHttp;
}